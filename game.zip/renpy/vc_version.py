branch = 'fix'
nightly = False
official = True
version = '8.2.2.24061201'
version_name = '64bit Sensation'
