import os
from datetime import datetime, timezone

def update_file_timestamp(file_path):
    try:
        # Get the file's modification time
        mtime = os.path.getmtime(file_path)
        # Convert to datetime
        file_date = datetime.fromtimestamp(mtime, tz=timezone.utc)
        # Check if the date is before 1980
        if file_date.year < 1980:
            # Set to a valid date (January 1, 1980)
            valid_date = datetime(1980, 1, 1, tzinfo=timezone.utc)
            valid_timestamp = valid_date.timestamp()
            os.utime(file_path, (valid_timestamp, valid_timestamp))
            print(f"Updated timestamp for {file_path}")
    except Exception as e:
        print(f"Error updating timestamp for {file_path}: {e}")

def update_timestamps_in_directory(directory):
    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            update_file_timestamp(file_path)
    print("Timestamp update completed.")

# Update timestamps for files in the game directory and other relevant directories
update_timestamps_in_directory(".")
